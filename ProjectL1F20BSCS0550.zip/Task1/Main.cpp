#include "Paragraph.h"
int main()
{
    Paragraph obj;
    ifstream fin;
    fin.open("Data.txt");
    fin >> obj;
    +obj;
    cout << obj;
    -obj;
    cout << obj;
    Paragraph obj1 = obj;
    //  obj1.output();
    Paragraph obj3;

    obj3 = obj1;
    cout << endl
         << endl
         << endl;
    //  cout << obj3;
    if (obj != obj1)
        cout << "Hello";
    return 0;
}
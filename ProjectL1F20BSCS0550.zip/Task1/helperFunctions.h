#pragma once

int strLength(const char *src);
void deepCopy(char *&dest, const char *src);
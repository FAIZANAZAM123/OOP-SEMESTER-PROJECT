#include "Paragraph.h"
Paragraph::Paragraph()
{
    para = nullptr;
    sentenceCount = 0;
    wordCountSize = 0;
    wordCount = nullptr;
}
void Paragraph::readData(const char *fileName)
{
    ifstream fin;
    fin.open(fileName);
    while (!fin.eof())
    {
        regrowS(para, sentenceCount);
        int *temp;
        temp = new int[wordCountSize + 1];
        for (int i = 0; i < wordCountSize; i++)
        {
            temp[i] = wordCount[i];
        }
        if (wordCount != nullptr)
            delete[] wordCount;
        wordCount = nullptr;
        wordCountSize++;
        temp[wordCountSize - 1] = 0;
        wordCount = temp;

        char arr[20];
        fin >> arr;
        int len = strLength(arr);
        while (arr[len - 1] != '.')
        {
            regrowW(para[sentenceCount - 1], wordCount[wordCountSize - 1]);
            para[sentenceCount - 1][wordCount[wordCountSize - 1] - 1] = new char *[len + 1];
            for (int i = 0; i < len; i++)
            {
                para[sentenceCount - 1][wordCount[wordCountSize - 1] - 1][i] = new char;
                *para[sentenceCount - 1][wordCount[wordCountSize - 1] - 1][i] = arr[i];
            }
            para[sentenceCount - 1][wordCount[wordCountSize - 1] - 1][len] = new char;
            *para[sentenceCount - 1][wordCount[wordCountSize - 1] - 1][len] = '\0';
            fin >> arr;
            len = strLength(arr);
            if (arr[len - 1] == '.')
            {
                regrowW(para[sentenceCount - 1], wordCount[wordCountSize - 1]);
                para[sentenceCount - 1][wordCount[wordCountSize - 1] - 1] = new char *[len + 1];
                for (int i = 0; i < len; i++)
                {
                    para[sentenceCount - 1][wordCount[wordCountSize - 1] - 1][i] = new char;
                    *para[sentenceCount - 1][wordCount[wordCountSize - 1] - 1][i] = arr[i];
                }
                para[sentenceCount - 1][wordCount[wordCountSize - 1] - 1][len] = new char;
                *para[sentenceCount - 1][wordCount[wordCountSize - 1] - 1][len] = '\0';
            }
        }
    }
}

Paragraph::~Paragraph()
{
    if (para != nullptr)
    {
        for (int i = 0; i < sentenceCount; i++)
        {
            for (int j = 0; j < wordCount[i]; j++)
            {
                for (int k = 0; *para[i][j][k] != '\0'; k++)
                {
                    if (para[i][j][k] != nullptr)
                        delete para[i][j][k];
                }
                if (para[i][j] != nullptr)
                    delete[] para[i][j];
            }
            if (para[i] != nullptr)
                delete[] para[i];
        }
        delete[] para;
        para = nullptr;
    }
    if (wordCount != nullptr)
    {
        delete[] wordCount;
        wordCount = nullptr;
    }
}
Paragraph::Paragraph(const Paragraph &obj)
{
    para = nullptr;
    sentenceCount = 0;
    wordCountSize = 0;
    wordCount = nullptr;
    for (int i = 0; i < obj.sentenceCount; i++)
    {
        regrowS(para, sentenceCount);
        int *temp;
        temp = new int[wordCountSize + 1];
        for (int m = 0; m < wordCountSize; m++)
        {
            temp[m] = wordCount[m];
        }
        if (wordCount != nullptr)
            delete[] wordCount;
        wordCount = nullptr;
        wordCountSize++;
        temp[wordCountSize - 1] = 0;
        wordCount = temp;

        for (int j = 0; j < obj.wordCount[i]; j++)
        {
            regrowW(para[i], wordCount[i]);
            int len = 0;
            for (len; *obj.para[i][j][len] != '\0'; len++)
                ;
            para[i][j] = new char *[len + 1];
            for (int n = 0; n < len; n++)
            {
                para[i][j][n] = new char;
                *para[i][j][n] = *obj.para[i][j][n];
            }
            para[i][j][len] = new char;
            *para[i][j][len] = '\0';
        }
    }
}

void regrowW(char ***&words, int &size)
{
    char ***temp = nullptr;
    temp = new char **[size + 1];
    for (int i = 0; i < size; i++)
    {
        temp[i] = words[i];
        words[i] = nullptr;
    }
    size++;
    if (words != nullptr)
        delete[] words;
    words = nullptr;
    words = temp;
    temp = nullptr;
    words[size - 1] = nullptr;
}

void regrowS(char ****&para, int &sentenceCount)
{
    char ****temp;
    temp = new char ***[sentenceCount + 1];
    for (int i = 0; i < sentenceCount; i++)
    {
        temp[i] = para[i];
        para[i] = nullptr;
    }
    sentenceCount++;
    if (para != nullptr)
        delete[] para;
    para = nullptr;
    para = temp;
    para[sentenceCount - 1] = nullptr;
}

Paragraph &Paragraph::operator=(const Paragraph &obj)
{

    if (para != nullptr)
    {
        for (int i = 0; i < sentenceCount; i++)
        {
            for (int j = 0; j < wordCount[i]; j++)
            {
                for (int k = 0; *para[i][j][k] != '\0'; k++)
                {
                    if (para[i][j][k] != nullptr)
                        delete para[i][j][k];
                }
                if (para[i][j] != nullptr)
                    delete[] para[i][j];
            }
            if (para[i] != nullptr)
                delete[] para[i];
        }
        delete[] para;
    }

    sentenceCount = 0;
    wordCountSize = 0;
    wordCount = nullptr;
    for (int i = 0; i < obj.sentenceCount; i++)
    {
        regrowS(para, sentenceCount);
        int *temp;
        temp = new int[wordCountSize + 1];
        for (int m = 0; m < wordCountSize; m++)
        {
            temp[m] = wordCount[m];
        }
        if (wordCount != nullptr)
            delete[] wordCount;
        wordCount = nullptr;
        wordCountSize++;
        temp[wordCountSize - 1] = 0;
        wordCount = temp;

        for (int j = 0; j < obj.wordCount[i]; j++)
        {
            regrowW(para[i], wordCount[i]);
            int len = 0;
            for (len; *obj.para[i][j][len] != '\0'; len++)
                ;
            para[i][j] = new char *[len + 1];
            for (int n = 0; n < len; n++)
            {
                para[i][j][n] = new char;
                *para[i][j][n] = *obj.para[i][j][n];
            }
            para[i][j][len] = new char;
            *para[i][j][len] = '\0';
        }
    }
    return *this;
}

bool Paragraph::operator==(const Paragraph &obj)
{

    bool flag = false;
    if (sentenceCount == obj.sentenceCount && wordCountSize == obj.wordCountSize)
    {

        for (int i = 0; i < wordCountSize; i++)
        {
            if (wordCount[i] == obj.wordCount[i])
                flag = true;
            else
                flag = false;
        }
    }
    else
        flag = false;
    if (flag)
        for (int i = 0; i < sentenceCount; i++)
        {

            for (int j = 0; j < wordCount[i]; j++)
            {
                for (int k = 0; *para[i][j][k] != '\0'; k++)
                {

                    if (*para[i][j][k] == *obj.para[i][j][k])
                        flag = true;
                    else
                    {
                        return false;
                        break;
                    }
                }
            }
        }
    return flag;
}

bool Paragraph::operator!=(const Paragraph &obj)
{
    if (!(*this == obj))
        return true;
    else
        return false;
}
ostream &operator<<(ostream &out, const Paragraph &obj)
{
    for (int i = 0; i < obj.sentenceCount; i++)
    {

        for (int j = 0; j < obj.wordCount[i]; j++)
        {
            for (int k = 0; *obj.para[i][j][k] != '\0'; k++)
            {

                out << obj.para[i][j][k][0];
            }
            out << " ";
        }
        out << endl;
    }
    return out;
}
ifstream &operator>>(ifstream &in, Paragraph &obj)
{
    while (!in.eof())
    {
        regrowS(obj.para, obj.sentenceCount);
        int *temp;
        temp = new int[obj.wordCountSize + 1];
        for (int i = 0; i < obj.wordCountSize; i++)
        {
            temp[i] = obj.wordCount[i];
        }
        if (obj.wordCount != nullptr)
            delete[] obj.wordCount;
        obj.wordCount = nullptr;
        obj.wordCountSize++;
        temp[obj.wordCountSize - 1] = 0;
        obj.wordCount = temp;

        char arr[20];
        in >> arr;
        int len = strLength(arr);
        while (arr[len - 1] != '.')
        {
            regrowW(obj.para[obj.sentenceCount - 1], obj.wordCount[obj.wordCountSize - 1]);
            obj.para[obj.sentenceCount - 1][obj.wordCount[obj.wordCountSize - 1] - 1] = new char *[len + 1];
            for (int i = 0; i < len; i++)
            {
                obj.para[obj.sentenceCount - 1][obj.wordCount[obj.wordCountSize - 1] - 1][i] = new char;
                *obj.para[obj.sentenceCount - 1][obj.wordCount[obj.wordCountSize - 1] - 1][i] = arr[i];
            }
            obj.para[obj.sentenceCount - 1][obj.wordCount[obj.wordCountSize - 1] - 1][len] = new char;
            *obj.para[obj.sentenceCount - 1][obj.wordCount[obj.wordCountSize - 1] - 1][len] = '\0';
            in >> arr;
            len = strLength(arr);
            if (arr[len - 1] == '.')
            {
                regrowW(obj.para[obj.sentenceCount - 1], obj.wordCount[obj.wordCountSize - 1]);
                obj.para[obj.sentenceCount - 1][obj.wordCount[obj.wordCountSize - 1] - 1] = new char *[len + 1];
                for (int i = 0; i < len; i++)
                {
                    obj.para[obj.sentenceCount - 1][obj.wordCount[obj.wordCountSize - 1] - 1][i] = new char;
                    *obj.para[obj.sentenceCount - 1][obj.wordCount[obj.wordCountSize - 1] - 1][i] = arr[i];
                }
                obj.para[obj.sentenceCount - 1][obj.wordCount[obj.wordCountSize - 1] - 1][len] = new char;
                *obj.para[obj.sentenceCount - 1][obj.wordCount[obj.wordCountSize - 1] - 1][len] = '\0';
            }
        }
    }
    return in;
}

Paragraph Paragraph::operator+()
{
    for (int i = 0; i < sentenceCount; i++)
    {

        for (int j = 0; j < wordCount[i]; j++)
        {
            for (int k = 0; *para[i][j][k] != '\0'; k++)
            {
                if ((para[i][j][k][0] >= 97) && (para[i][j][k][0] <= 122))
                {
                    para[i][j][k][0] -= 32;
                }
            }
        }
    }
    return *this;
}

Paragraph Paragraph::operator-()
{
    for (int i = 0; i < sentenceCount; i++)
    {

        for (int j = 0; j < wordCount[i]; j++)
        {
            for (int k = 0; *para[i][j][k] != '\0'; k++)
            {
                if ((para[i][j][k][0] >= 65) && (para[i][j][k][0] <= 90))
                {
                    para[i][j][k][0] += 32;
                }
            }
        }
    }
    return *this;
}
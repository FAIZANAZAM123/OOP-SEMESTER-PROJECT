#include <iostream>
#include <fstream>
#include "helperFunctions.h"
using namespace std;
class Paragraph
{
private:
    char ****para;
    int sentenceCount;
    int *wordCount;
    int wordCountSize;

public:
    Paragraph();
    Paragraph(const Paragraph &obj);
    ~Paragraph();
    void readData(const char *fileName);
    Paragraph &operator=(const Paragraph &obj);
    bool operator==(const Paragraph &obj);
    bool operator!=(const Paragraph &obj);
    friend ostream &operator<<(ostream &out, const Paragraph &obj);
    friend ifstream &operator>>(ifstream &in, Paragraph &obj);
    Paragraph operator+();
    Paragraph operator-();
};

void regrowW(char ***&words, int &size);
void regrowS(char ****&para, int &sentenceCount);
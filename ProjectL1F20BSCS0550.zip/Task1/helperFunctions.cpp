#include"helperFunctions.h"

int strLength(const char* src)
{
	int length = {};
	for (length; src[length] != '\0'; length++);

	return length;
}
void deepCopy(char*& dest, const char* src)
{
	if (src)
	{
		if (dest)
		{
			delete[]dest;
			dest = nullptr;
		}
		int length = strLength(src);
		dest = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			dest[i] = src[i];
		}
		dest[length] = '\0';
	}

	else
	{
		dest = nullptr;
	}
}
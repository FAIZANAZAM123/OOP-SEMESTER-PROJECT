#include "Paragraph.h"
int Paragraph::countPara = 0;
Paragraph::Paragraph()
{
    sentences = nullptr;
    noOfSentences = 0;
    countPara++;
    paraNo = countPara;
    encrypted = false;
}
Paragraph::Paragraph(const Paragraph &obj)
{
    noOfSentences = obj.noOfSentences;
    sentences = new Sentence[noOfSentences];
    encrypted = obj.encrypted;
    for (int i = 0; i < noOfSentences; i++)
    {
        sentences[i] = obj.sentences[i];
    }
    countPara++;
    paraNo = countPara;
}
Paragraph &Paragraph::operator=(const Paragraph &obj)
{
    if (this != &obj)
    {
        noOfSentences = obj.noOfSentences;
        encrypted = obj.encrypted;
        if (sentences != nullptr)
        {
            delete[] sentences;
            sentences = nullptr;
        }
        sentences = new Sentence[noOfSentences];
        for (int i = 0; i < noOfSentences; i++)
        {
            sentences[i] = obj.sentences[i];
        }
    }
    return *this;
}
Paragraph::~Paragraph()
{
    if (sentences != nullptr)
    {
        delete[] sentences;
        sentences = nullptr;
    }
    countPara--;
}
int Paragraph::getNoOfSentences()
{
    return noOfSentences;
}
ifstream &operator>>(ifstream &in, Paragraph &obj)
{
    if (in.is_open())
    {
        while (!in.eof())
        {
            obj.addSentence();

            in >> obj[obj.getNoOfSentences() - 1];
        }
    }
    else
    {
        cout << " Error! file not found" << endl;
    }
    return in;
}
void Paragraph::addSentence()
{
    Sentence *temp = new Sentence[noOfSentences + 1];
    for (int i = 0; i < noOfSentences; i++)
    {
        temp[i] = sentences[i];
    }
    delete[] sentences;
    sentences = nullptr;
    sentences = temp;
    noOfSentences++;
}
Sentence &Paragraph::operator[](int index)
{
    return sentences[index];
}
const Sentence &Paragraph::operator[](int index) const
{
    return sentences[index];
}

ostream &operator<<(ostream &out, Paragraph &obj)
{
    for (int i = 0; i < obj.getNoOfSentences(); i++)
    {
        out << obj[i];
        out << endl;
    }
    return out;
}
ofstream &operator<<(ofstream &fout, Paragraph &obj)
{
    for (int i = 0; i < obj.getNoOfSentences(); i++)
    {
        fout << obj[i];
        fout << endl;
    }
    return fout;
}
bool Paragraph::operator==(const Paragraph &obj)
{
    bool flag = false;
    if (noOfSentences == obj.noOfSentences)
        for (int i = 0; i < noOfSentences; i++)
        {
            if (sentences[i] == obj.sentences[i])
            {
                flag = true;
                continue;
            }
            else
            {
                flag = false;
                break;
            }
        }
    return flag;
}

Paragraph Paragraph::operator+()
{
    for (int i = 0; i < noOfSentences; i++)
    {
        sentences[i].operator+();
    }
    return *this;
}

Paragraph Paragraph::operator-()
{
    for (int i = 0; i < noOfSentences; i++)
    {
        sentences[i].operator-();
    }
    return *this;
}
int Paragraph::getPunctuationChar()
{
    int punk = 0;
    for (int i = 0; i < noOfSentences; i++)
    {
        int temp = sentences[i].getPunc();
        punk = punk + temp;
    }

    return punk;
}
int Paragraph::getEnglishChar()
{
    int eng = 0;
    for (int i = 0; i < noOfSentences; i++)
    {
        int temp = sentences[i].getEng();
        eng = eng + temp;
    }
    return eng;
}
void Paragraph::operator%(int key)
{
    if (encrypted == false)
    {
        for (int i = 0; i < noOfSentences; i++)
        {
            sentences[i] % key;
        }
        encrypted = true;
        cout << "Paragraph is successfully encrypted. " << endl;
    }
    else
    {
        cout << "Paragraph is already encrypted." << endl;
    }
}
void Paragraph::operator*(int key)
{
    if (encrypted == true)
    {
        for (int i = 0; i < noOfSentences; i++)
        {
            sentences[i] * key;
        }
        encrypted = false;
        cout << "Paragraph is successfully decrypted. " << endl;
    }
    else
    {
        cout << "Paragraph is already decrypted." << endl;
    }
}

Paragraph Paragraph::operator+(const Paragraph &obj)
{
    Paragraph temp;
    temp.noOfSentences = 0;
    for (size_t i = 0; i < noOfSentences; i++)
    {
        temp.addSentence();
        temp.sentences[temp.noOfSentences - 1] = sentences[i];
    }
    for (int i = 0; i < obj.noOfSentences; i++)
    {
        temp.addSentence();
        temp.sentences[temp.noOfSentences - 1] = obj.sentences[i];
    }
    return temp;
}

void Paragraph::frequency()
{
    ofstream fout;
    fout.open("frequency.txt");
    fout
        << "Paragraph No. " << paraNo << endl;
    fout << "     Sentences in Paragraph " << paraNo << " : " << noOfSentences << endl;
    for (int i = 0; i < noOfSentences; i++)
    {
        fout << "          Words in Sentence NO. " << i + 1 << " : " << sentences[i].getNoOfWords() << endl;
        for (int j = 0; j < sentences[i].getNoOfWords(); j++)
        {
            fout << "               Characters in Word no. " << j + 1 << " : " << strLength(sentences[i].getWord(j)) << endl;
        }
    }
    fout.close();
}

Paragraph::Paragraph(Paragraph &&obj)
{
    sentences = obj.sentences;
    noOfSentences = obj.noOfSentences;
    encrypted = obj.encrypted;
    obj.sentences = nullptr;
    obj.noOfSentences = 0;
    obj.encrypted = false;
}

Paragraph &Paragraph::operator=(Paragraph &&obj)
{
    if (this != &obj)
    {
        sentences = obj.sentences;
        noOfSentences = obj.noOfSentences;
        encrypted = obj.encrypted;
        obj.sentences = nullptr;
        obj.noOfSentences = 0;
        obj.encrypted = false;
    }
    return *this;
}

void Paragraph::spellCheck()
{
    ifstream fin;
    fin.open("Dictionary.txt");
    Paragraph dictionary;
    if (fin.is_open())
    {
        fin >> dictionary;

        cout << " Words that are not present in Dictionary: " << endl;
        for (int i = 0; i < noOfSentences; i++)
        {
            for (int j = 0; j < sentences[i].getNoOfWords(); j++)
            {
                bool flag = false;

                char *w = sentences[i].getWord(j);
                int len = strLength(w);
                if (w[len - 1] == '.')
                    w[len - 1] = '\0';
                for (int k = 0; k < dictionary.noOfSentences; k++)
                {
                    for (int l = 0; l < dictionary.sentences[k].getNoOfWords(); l++)
                    {

                        if (!strcmp(dictionary.sentences[k].getWord(l), w))
                        {
                            flag = true;
                        }
                    }
                }
                if (flag == false)
                {

                    cout << w << endl;
                }
                delete[] w;
                w = nullptr;
            }
        }
    }
    else
    {
        cout << " Error! Dictionary.txt could not be found." << endl;
    }
}
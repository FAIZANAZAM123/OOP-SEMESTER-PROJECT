#include "Sentence.h"
Sentence::Sentence()
{
    words = nullptr;
    noOfWords = 0;
}
Sentence::Sentence(const Sentence &obj)
{
    noOfWords = obj.noOfWords;

    words = new Word[noOfWords];
    for (int i = 0; i < noOfWords; i++)
    {
        words[i] = obj.words[i];
    }
}
Sentence::~Sentence()
{
    if (words != nullptr)
    {
        delete[] words;
        words = nullptr;
    }
}
Sentence &Sentence::operator=(const Sentence &obj)
{
    if (this != &obj)
    {
        if (words != nullptr)
        {
            delete[] words;
            words = nullptr;
        }
        noOfWords = obj.noOfWords;
        words = new Word[noOfWords];
        for (int i = 0; i < noOfWords; i++)
        {
            words[i] = obj.words[i];
        }
    }
    return *this;
}

int Sentence::getNoOfWords() const
{
    return noOfWords;
}
char *Sentence::getWord(int no) const
{
    return words[no].getWord();
}
void Sentence::addWord(const char *w)
{
    Word *temp = new Word[noOfWords + 1];
    for (int i = 0; i < noOfWords; i++)
    {
        temp[i] = words[i];
    }
    delete[] words;
    words = nullptr;
    temp[noOfWords].setWord(w);

    words = temp;
    noOfWords++;
}

ostream &operator<<(ostream &out, const Sentence &obj)
{
    char *temp = nullptr;
    for (int i = 0; i < obj.getNoOfWords(); i++)
    {
        temp = obj.getWord(i);
        out << temp << " ";
        delete[] temp;
        temp = nullptr;
    }
    return out;
}

ifstream &operator>>(ifstream &in, Sentence &obj)
{
    while (!in.eof())
    {

        char temp[20];
        in >> temp;
        int len = strLength(temp);
        if (temp[len - 1] != '.')
            obj.addWord(temp);
        else
        {
            obj.addWord(temp);
            break;
        }
    }
    return in;
}

ofstream &operator<<(ofstream &out, Sentence &obj)
{
    char *temp = nullptr;
    for (int i = 0; i < obj.getNoOfWords(); i++)
    {
        temp = obj.getWord(i);
        out << temp << " ";
        delete[] temp;
        temp = nullptr;
    }
    return out;
}
bool Sentence::operator==(const Sentence &obj)
{
    bool flag = false;
    if (noOfWords == obj.noOfWords)
        for (int i = 0; i < noOfWords; i++)
        {
            if (words[i] == obj.words[i])
            {
                flag = true;
                continue;
            }
            else
            {
                flag = false;
                break;
            }
        }

    return flag;
}

Word &Sentence::operator[](int index)
{
    return words[index];
}
const Word &Sentence::operator[](int index) const
{
    return words[index];
}

Sentence Sentence::operator+()
{
    for (int i = 0; i < noOfWords; i++)
    {
        words[i].operator+();
    }
    return *this;
}

Sentence Sentence::operator-()
{
    for (int i = 0; i < noOfWords; i++)
    {
        words[i].operator-();
    }
    return *this;
}
int Sentence::getPunc()
{

    int countPunc = 0;

    for (int i = 0; i < noOfWords; i++)
    {

        int temp = words[i].getPunc();
        countPunc = countPunc + temp;
    }

    return countPunc;
}
int Sentence::getEng()
{
    int countEng = 0;
    for (int i = 0; i < noOfWords; i++)
    {
        int temp = words[i].getEnglish();
        countEng = countEng + temp;
    }

    return countEng;
}

void Sentence::operator%(int key)
{
    for (int i = 0; i < noOfWords; i++)
    {
        words[i] % key;
    }
}

void Sentence::operator*(int key)
{
    for (int i = 0; i < noOfWords; i++)
    {
        words[i] * key;
    }
}

Sentence::Sentence(Sentence &&obj)
{
    words = obj.words;
    noOfWords = obj.noOfWords;
    obj.words = nullptr;
    noOfWords = 0;
}

Sentence &Sentence::operator=(Sentence &&obj)
{
    if (this != &obj)
    {
        words = obj.words;
        noOfWords = obj.noOfWords;
        obj.words = nullptr;
        noOfWords = 0;
    }
    return *this;
}
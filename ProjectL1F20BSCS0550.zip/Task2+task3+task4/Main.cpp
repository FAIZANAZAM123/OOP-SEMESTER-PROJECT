#include "Paragraph.h"
int main()
{
    Paragraph para1, para2;

    ifstream fin;
    fin.open("Hello.txt");
    fin >> para1;
    para2 = para1;
    Paragraph para3 = para1;
    cout << " Before Encryption : ";
    cout << para1;

    para1 % 3;
    cout << " After Encryption : ";
    cout << para1;
    para1 * 3;
    cout << " After Decryption : ";
    cout << para1;

    if (para1 == para2)
        cout << "Both are equal" << endl;
    else
        cout << "Both are not equal" << endl;

    cout << "Using Unary + operator : ";
    +para2;
    cout << para2;
    cout << "Using unary - operator : ";
    -para2;
    cout << para2;
    para2.spellCheck();
    fin.close();
    ofstream fout;
    fout.open("output.txt");
    fout << para1;
    fout.close();
    return 0;
}

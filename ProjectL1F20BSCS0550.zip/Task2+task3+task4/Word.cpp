#include "Word.h"
Word::Word(const char *w, int letters)
{
    word = nullptr;
    if (w != nullptr)
        noOfLetters = strLength(w);
    else
        noOfLetters = 0;

    deepCopy(word, w);
}
Word::Word(const Word &obj)
{
    word = nullptr;

    noOfLetters = obj.noOfLetters;
    deepCopy(word, obj.word);
}

Word &Word::operator=(const Word &obj)
{
    if (this != &obj)
    {
        if (word != nullptr)
            delete[] word;
        word = nullptr;
        deepCopy(word, obj.word);
        noOfLetters = obj.noOfLetters;
    }

    return *this;
}
void Word::setWord(const char *w)
{

    if (word != nullptr)
    {
        delete[] word;
        word = nullptr;
    }
    deepCopy(word, w);
    noOfLetters = strLength(w);
}

char *Word::getWord() const
{
    char *temp = nullptr;
    deepCopy(temp, word);
    return temp;
}
Word::~Word()
{
    if (word != nullptr)
    {
        delete[] word;
        word = nullptr;
    }
}

ostream &operator<<(ostream &out, const Word &obj)
{
    char *temp = nullptr;
    temp = obj.getWord();
    out << temp;
    out << " ";
    return out;
}

bool Word::operator==(const Word &obj)
{
    bool flag = false;
    int len = strLength(word);
    int len2 = strLength(obj.word);
    if (len == len2)
        for (int i = 0; i < len; i++)
        {
            if (word[i] == obj.word[i])
            {
                flag = true;
                continue;
            }
            else
            {
                flag = false;
                break;
            }
        }
    return flag;
}

Word Word::operator+()
{
    for (int i = 0; i < noOfLetters; i++)
    {
        if (word[i] >= 97 && word[i] <= 122)
            word[i] -= 32;
    }
    return *this;
}

Word Word::operator-()
{
    for (int i = 0; i < noOfLetters; i++)
    {
        if (word[i] >= 65 && word[i] <= 90)
            word[i] += 32;
    }
    return *this;
}
int Word::getPunc()
{

    char temp[] = {'?', '\'', '\"', ';', ',', ':', '!', '-', '[', ']', '{', '}', '(', ')', '.'};
    int punctuation = 0;
    for (int i = 0; i < noOfLetters; i++)
    {
        for (int j = 0; j < 15; j++)
        {
            if (word[i] == temp[j])
                punctuation++;
        }
    }
    return punctuation;
}
int Word::getEnglish()
{
    int englishChar = 0;

    for (int i = 0; i < strLength(word); i++)
    {
        if ((word[i] >= 65 && word[i] <= 90) || (word[i] >= 90 && word[i] <= 122))
            englishChar++;
    }

    return englishChar;
}

void Word::operator%(int key)
{
    char temp[] = {'?', '\'', '\"', ';', ',', ':', '!', '-', '[', ']', '{', '}', '(', ')', '.'};
    for (int i = 0; i < noOfLetters; i++)
    {
        for (int j = 0; j < key; j++)
        {
            if ((word[i] >= 65 && word[i] <= 90) || (word[i] >= 97 && word[i] <= 122))
            {
                if (word[i] == 'z')
                    word[i] = 'a';
                if (word[i] == 'Z')
                    word[i] = 'A';
                word[i]++;
            }
        }
        for (int j = 0; j < 15; j++)
        {
            if (word[i] == temp[j])
            {
                word[i] += key;
                break;
            }
        }
    }
}

void Word::operator*(int key)
{
    char temp[] = {'?', '\'', '\"', ';', ',', ':', '!', '-', '[', ']', '{', '}', '(', ')', '.'};
    for (int i = 0; i < noOfLetters; i++)
    {
        if ((word[i] >= 65 && word[i] <= 90) || (word[i] >= 97 && word[i] <= 122))
        {
            for (int j = 0; j < key; j++)
            {

                if (word[i] == 'a')
                    word[i] = 'z';
                if (word[i] == 'A')
                    word[i] = 'Z';
                word[i]--;
            }
        }
        else
        {
            for (int j = 0; j < 15; j++)
            {
                if (word[i] == temp[j] + key)
                {
                    word[i] -= key;
                    break;
                }
            }
        }
    }
}
Word::Word(Word &&obj)
{
    word = obj.word;
    noOfLetters = obj.noOfLetters;
    obj.word = nullptr;
    obj.noOfLetters = 0;
}
Word &Word::operator=(Word &&obj)
{
    if (this != &obj)
    {
        word = obj.word;
        noOfLetters = obj.noOfLetters;
        obj.word = nullptr;
        obj.noOfLetters = 0;
    }
    return *this;
}
#include "Sentence.h"
#include <cstring>
class Paragraph
{
private:
    Sentence *sentences;
    int noOfSentences;
    static int countPara;
    int paraNo;
    bool encrypted;

public:
    Paragraph();                                 //Default Constructor
    Paragraph(const Paragraph &obj);             //Copy Constructor
    Paragraph &operator=(const Paragraph &obj);  //Operator=
    ~Paragraph();                                //Destructor
    void addSentence();                          //Function to add a new sentence in the paragraph
    Sentence &operator[](int index);             //indexing operator
    const Sentence &operator[](int index) const; //indexing operator for constant objects of class Paragraph
    int getNoOfSentences();                      //Getter
    bool operator==(const Paragraph &obj);       //operator == for comparison
    Paragraph operator+();                       //Unary + operator to convert whole paragraph into upper case
    Paragraph operator-();                       //Unary - operator to convert whole paragraph into lower case
    int getPunctuationChar();                    //To find the total punctuation in paragraph
    int getEnglishChar();                        //To find the total number of english characters in paragraph
    void operator%(int key);                     //Unary % operator to encrypt plain text
    void operator*(int key);                     //Unary * operator to decrypt an encrypted paragraph
    Paragraph operator+(const Paragraph &obj);   //Binary + operator to join two paragraphs
    void frequency();                            //Function to create frequency.txt
    Paragraph(Paragraph &&obj);                  //Move Copy Constructer
    Paragraph &operator=(Paragraph &&obj);       //Move Assignment operator
    void spellCheck();
};
ifstream &operator>>(ifstream &in, Paragraph &obj);   //fin >> to read a paragraph from a file
ostream &operator<<(ostream &out, Paragraph &obj);    //cout << to display a paragraph on console
ofstream &operator<<(ofstream &fout, Paragraph &obj); //fout << to write the data to a file.
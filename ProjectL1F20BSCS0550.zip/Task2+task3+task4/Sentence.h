#include "Word.h"
class Sentence
{
private:
    Word *words;
    int noOfWords;

public:
    Sentence();                               //Default Constructor
    Sentence(const Sentence &obj);            //Copy Constructor
    ~Sentence();                              //Destructor
    Sentence &operator=(const Sentence &obj); //Assignment operator
    int getNoOfWords() const;                 //Getter
    char *getWord(int no) const;              //Getter
    void addWord(const char *w);              // Function to add a new word in the current sentence
    bool operator==(const Sentence &obj);     //Operator == to check if two sentences are equal
    Word &operator[](int index);              //Indexing Operator
    const Word &operator[](int index) const;  //Indexing operator for constant functions
    Sentence operator+();                     //Unary + operator to convert a sentence in upper case
    Sentence operator-();                     //Unary - operator to convert a sentence in lower case
    int getPunc();                            //Function to count the number of punctuations in a sentence
    int getEng();                             //Function to count the number of English characters in a sentence
    void operator%(int key);                  //Unary % operator to encrypt a sentence
    void operator*(int key);                  //Unary * operator to decrypt an encrypted sentence
    Sentence(Sentence &&obj);                 //Move Copy Constructor
    Sentence &operator=(Sentence &&obj);      //Move Assignment Operator
};

ostream &operator<<(ostream &out, const Sentence &obj);
ifstream &operator>>(ifstream &in, Sentence &obj);
ofstream &operator<<(ofstream &out, Sentence &obj);
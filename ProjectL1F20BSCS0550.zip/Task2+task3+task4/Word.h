#include <iostream>
#include <fstream>
#include "helperFunctions.h"
using namespace std;
class Word
{
private:
    char *word;
    int noOfLetters;

public:
    Word(const char *w = nullptr, int letters = 0); //Parametrized Constructor with default values
    Word(const Word &obj);                          //Copy Constructor
    Word &operator=(const Word &obj);               //Assignment Operator
    ~Word();                                        //Destructor
    void setWord(const char *w);                    //Setter
    char *getWord() const;                          //Getter
    bool operator==(const Word &obj);               //Operator == to check if two words are equal
    Word operator+();                               //Unary + operator to convert a word into upper case
    Word operator-();                               //Unary - operator to convert a word into lower case
    int getPunc();                                  //Function to find the number of puntuations in a word
    int getEnglish();                               //Function to find the number of English Characters in a word
    void operator%(int key);                        //Unary operator % to encrypt a word
    void operator*(int key);                        //Unary operator * to decrypt an encrypted word
    Word(Word &&obj);                               //Move Copy Constructor
    Word &operator=(Word &&obj);                    //Move Assignment Operator
};
ostream &operator<<(ostream &out, const Word &obj);
